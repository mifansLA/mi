#!/sbin/sh

busybox mkdir -p /sdcard/Backup_buildprop
busybox mkdir -p /storage/sdcard1/Backup_buildprop
busybox cp /system/build.prop /sdcard/Backup_buildprop
busybox cp /system/build.prop /storage/sdcard1/Backup_buildprop
busybox sed -i '/ro.product.device/ c ro.product.device=ido_mifansLA' /system/build.prop
busybox sed -i '/ro.product.mod_device/ c ro.product.mod_device=ido_xhdpi_global' /system/build.prop
chmod 644 /system/build.prop